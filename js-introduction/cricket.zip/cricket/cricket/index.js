let sachin= require("./data/sachin.json");
let sehwag= require("./data/sehwag.json");
let yuvraj= require("./data/yuvraj.json");
let dravid= require("./data/dravid.json");
let ganguly= require("./data/ganguly.json");
let virat= require("./data/virat.json");
const data = {sachin,sehwag,yuvraj,dravid,ganguly,virat}

//find the player with most fours
let mostFoursPlayer = "";
let mostFours = 0;

for (const player of Object.values(data)) {
  
  const fours = parseInt(player.data.batting.listA["4s"]);
  if (fours > mostFours) {
    mostFours = fours;
    mostFoursPlayer = player.name;
  }
}
console.log(`Player with most fours: ${mostFoursPlayer}`);

//find the player with most sixes
let mostsixPlayer = "";
let mostsix = 0;

for (const player of Object.values(data)) {
  const six = parseInt(player.data.batting.listA["6s"]);
  if (six > mostsix) {
    mostsix = six;
    mostsixPlayer = player.name;
  }
}
console.log(`Player with most six: ${mostsixPlayer}`);

//find the player with most runs
let mostrunPlayer = "";
let mostrun = 0;

for (const player of Object.values(data)) {
  
  const run = parseInt(player.data.batting.listA["Runs"]);
  if (run > mostrun) {
    mostrun = run;
    mostrunPlayer = player.name;
  }
}
console.log(`Player with most runs: ${mostrunPlayer}`);

//find the player with most wickets
let mostwktsPlayer = "";
let mostwkts = 0;

for (const player of Object.values(data)) {
  const wkts = parseInt(player.data.bowling.listA["Wkts"]);
  if (wkts > mostwkts) {
    mostwkts = wkts;
    mostwktsPlayer = player.name;
  }
}
console.log(`Player with most wickets: ${mostwktsPlayer}`);




